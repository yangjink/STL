#pragma once
#include <stdio.h>

void StaticFunc(int i);