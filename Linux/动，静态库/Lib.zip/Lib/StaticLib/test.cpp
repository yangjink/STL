#include "test.h"

void StaticFunc(int i)
{
	printf("StaticFunc(%d)\n", i);
}
