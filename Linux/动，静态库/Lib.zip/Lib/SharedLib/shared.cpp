#include "shared.h"

void SharedFunc(int i)
{
	printf("SharedFunc(%d)\n", i);
}

void SharedFunc1(int i)
{
	printf("SharedFunc1(%d)\n", i);
}

void AA::f1()
{
	printf("AA::f1\n");

}

void AA::f2()
{
	printf("AA::f2\n");

}
