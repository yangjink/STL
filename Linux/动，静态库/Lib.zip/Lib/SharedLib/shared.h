#pragma once
#include <stdio.h>

#ifdef _WIN32
	#define DLL_EXPORT _declspec(dllexport)
#else
	#define DLL_EXPORT
#endif

DLL_EXPORT void SharedFunc(int i);

DLL_EXPORT void SharedFunc1(int i);

class AA
{
public:
	void f1();
	void f2();
};
