#include <stdio.h>

//#include <test.h>
#include "../StaticLib/test.h"
#include "../SharedLib/shared.h"

int main()
{
	StaticFunc(100); // call StaticFunc(0xde1eqedqeq)
	SharedFunc(1000); // call SharedFunc(delay)
	SharedFunc1(1000); // call SharedFunc(delay)

	AA a1;
	a1.f1();
	a1.f2();
}