public class Hello{
  public static void main(String[]args){
      A.A();
      B abc=new B();
      abc.B();
      
     
     
   }
   

}
 class A{
     public static void A(){
        System.out.println("���Ǿ�̬");}

}
 class B{
     public  void B(){
        System.out.println("���ǷǾ�̬");}
}
 class c{}