
public class Txt2 

	{
		public static void main(String[] args)
		{
			String str;
			str="610631199510301615";
			if(getString(str))
			{
				System.out.println(Information(str));
			}
			else
			{
				System.out.println("����������");
			}
		}
		public static boolean getString(String str)
		{
			char ch;
			int i;
			for(i=0;i<str.length()-1;i++)
			{
				ch=str.charAt(i);
				if(!(ch>='0' && ch<='9'))
				{
					return false;
				}
			}
			if(str.length()==18) {
				if(str.charAt(17)=='x'||str.charAt(17)=='X'||(str.charAt(17)>='0'&&str.charAt(17)<='9'))
				
				{
				
				
				return true;}
				else
				{
					return false;
				}}
			
				
			
			
			else
			{
				return false;
			}
	         
		}
		public static String Information(String str)
		{
			String year, month, day;
			year=str.substring(6,10);
			month=str.substring(10,12);
			day=str.substring(12,14);
			if(((int)str.charAt(16))%2==0)
			{
				return "�𾴵�Ůʿ������"+year+"��"+month+"��"+day+"�ճ���!";
			}
			else
			{
				return "�𾴵�����������"+year+"��"+month+"��"+day+"�ճ���!";
			}
		}
	}
